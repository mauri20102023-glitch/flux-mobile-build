plugins {
    id("com.android.application")
}

android {
    namespace = "ai.flux.mobile"
    compileSdk = 35

    defaultConfig {
        applicationId = "ai.flux.mobile"
        minSdk = 28
        targetSdk = 35
        versionCode = 25
        versionName = "1.5.0"
    }

    signingConfigs {
        val storePath = System.getenv("FLUX_SIGNING_STORE_FILE")
        if (!storePath.isNullOrBlank()) {
            create("fluxRelease") {
                storeFile = file(storePath)
                storePassword = System.getenv("FLUX_SIGNING_STORE_PASSWORD")
                keyAlias = System.getenv("FLUX_SIGNING_KEY_ALIAS")
                keyPassword = System.getenv("FLUX_SIGNING_KEY_PASSWORD")
            }
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            signingConfig = if (signingConfigs.names.contains("fluxRelease")) {
                signingConfigs.getByName("fluxRelease")
            } else {
                signingConfigs.getByName("debug")
            }
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }
}
