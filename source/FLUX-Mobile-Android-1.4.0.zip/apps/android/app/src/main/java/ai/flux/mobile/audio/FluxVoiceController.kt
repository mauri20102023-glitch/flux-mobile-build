package ai.flux.mobile.audio

import android.content.Context
import ai.flux.mobile.data.FluxApiClient
import io.elevenlabs.ConversationClient
import io.elevenlabs.ConversationConfig
import io.elevenlabs.ConversationSession
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

/**
 * Real-time voice bridge for the private FLUX ATH ElevenLabs agent.
 *
 * Audio input, transcription, reasoning and audio output all stay inside the
 * same authenticated ElevenLabs conversation. There is deliberately no local
 * Android/Google speech recognizer or TextToSpeech fallback here.
 */
class FluxVoiceController(
    private val context: Context,
    private val api: FluxApiClient,
    private val onSessionChanged: (Boolean) -> Unit,
    private val onUserTranscript: (String) -> Unit,
    private val onAgentResponse: (String) -> Unit,
    private val onError: (String) -> Unit,
) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var session: ConversationSession? = null
    private var starting = false

    fun startSession() {
        if (starting || session != null) return
        starting = true
        onSessionChanged(true)
        scope.launch {
            runCatching {
                val credentials = api.voiceSession()
                ConversationClient.startSession(
                    ConversationConfig(
                        conversationToken = credentials.token,
                        userId = "mauricio",
                        audioInputSampleRate = 48000,
                        onConnect = { onSessionChanged(true) },
                        onDisconnect = { details ->
                            scope.launch {
                                session = null
                                starting = false
                                onSessionChanged(false)
                                if (details.reason == "error") {
                                    onError("A conversa de voz foi interrompida. Toque no microfone para reconectar.")
                                }
                            }
                        },
                        onStatusChange = { status ->
                            if (status.name == "ERROR") {
                                scope.launch {
                                    session = null
                                    starting = false
                                    onSessionChanged(false)
                                    onError("Não foi possível conectar à voz FLUX ATH.")
                                }
                            }
                        },
                        onError = { _, message ->
                            scope.launch {
                                onError(message?.takeIf(String::isNotBlank)
                                    ?: "Não foi possível conectar à voz FLUX ATH.")
                            }
                        },
                        onUserTranscriptEvent = { text, _ ->
                            text.trim().takeIf(String::isNotEmpty)?.let { transcript ->
                                scope.launch { onUserTranscript(transcript) }
                            }
                        },
                        onAgentResponseEvent = { text, _ ->
                            text.trim().takeIf(String::isNotEmpty)?.let { response ->
                                scope.launch { onAgentResponse(response) }
                            }
                        },
                    ),
                    context,
                )
            }.onSuccess { active ->
                session = active
                starting = false
            }.onFailure { failure ->
                session = null
                starting = false
                onSessionChanged(false)
                onError(failure.message?.takeIf(String::isNotBlank)
                    ?: "Não foi possível iniciar a voz FLUX ATH.")
            }
        }
    }

    fun endSession() {
        val active = session
        session = null
        starting = false
        scope.launch { runCatching { active?.endSession() } }
        onSessionChanged(false)
    }

    fun destroy() {
        val active = session
        session = null
        starting = false
        onSessionChanged(false)
        scope.launch {
            runCatching { active?.endSession() }
            scope.cancel()
        }
    }
}
