package ai.flux.mobile.assistant

import android.service.voice.VoiceInteractionService

class FluxVoiceInteractionService : VoiceInteractionService()
