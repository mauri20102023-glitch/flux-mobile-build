package ai.flux.mobile

import android.app.Activity
import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.util.Base64
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.security.KeyFactory
import java.security.SecureRandom
import java.security.Signature
import java.security.spec.PKCS8EncodedKeySpec
import java.util.UUID

/**
 * Entrada de recuperação do FLUX.
 *
 * Usa somente APIs nativas do Android durante toda a abertura. Compose,
 * ElevenLabs, WebRTC, Bluetooth e o painel avançado não são nem carregados.
 * O chat HTTPS também usa apenas HttpURLConnection e só começa depois de um
 * toque explícito em Enviar.
 */
class SafeMainActivity : Activity() {
    private lateinit var conversation: TextView
    private lateinit var status: TextView
    private lateinit var input: EditText
    private lateinit var send: Button
    private val preferences by lazy { getSharedPreferences("flux_safe_core", Context.MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(7, 8, 10)
        window.navigationBarColor = Color.rgb(7, 8, 10)
        setContentView(createInterface())
    }

    private fun createInterface(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(7, 8, 10))
            setPadding(dp(20), dp(20), dp(20), dp(16))
            fitsSystemWindows = true
        }

        root.addView(TextView(this).apply {
            text = "Olá, Maurício"
            textSize = 28f
            setTextColor(Color.WHITE)
            setTypeface(typeface, Typeface.BOLD)
        })
        root.addView(TextView(this).apply {
            text = "FLUX MOBILE 1.4.3  •  MODO ESTÁVEL"
            textSize = 11f
            letterSpacing = 0.12f
            setTextColor(Color.rgb(255, 48, 74))
            setPadding(0, dp(4), 0, dp(14))
        })

        status = TextView(this).apply {
            text = "PRONTO PARA CONVERSAR"
            textSize = 12f
            setTextColor(Color.rgb(82, 210, 127))
            setPadding(dp(14), dp(10), dp(14), dp(10))
            background = rounded(Color.rgb(17, 19, 24), 14, Color.rgb(48, 52, 61))
        }
        root.addView(status, LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)

        conversation = TextView(this).apply {
            text = "Esta versão abriu pelo núcleo seguro do Android.\n\nDigite uma mensagem para testar o FLUX Core."
            textSize = 17f
            setTextColor(Color.rgb(244, 246, 250))
            setLineSpacing(0f, 1.18f)
            setPadding(dp(16), dp(16), dp(16), dp(16))
        }
        val scroll = ScrollView(this).apply {
            isFillViewport = true
            background = rounded(Color.rgb(17, 19, 24), 18, Color.rgb(48, 52, 61))
            addView(conversation)
        }
        root.addView(scroll, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            0,
            1f,
        ).apply { setMargins(0, dp(14), 0, dp(14)) })

        input = EditText(this).apply {
            hint = "Fale com o FLUX..."
            setHintTextColor(Color.rgb(155, 162, 173))
            setTextColor(Color.WHITE)
            textSize = 16f
            maxLines = 4
            setPadding(dp(16), dp(13), dp(16), dp(13))
            background = rounded(Color.rgb(25, 28, 34), 16, Color.rgb(48, 52, 61))
        }
        root.addView(input, LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)

        send = Button(this).apply {
            text = "ENVIAR"
            textSize = 14f
            setTextColor(Color.WHITE)
            setTypeface(typeface, Typeface.BOLD)
            backgroundTintList = ColorStateList.valueOf(Color.rgb(255, 48, 74))
            setOnClickListener { sendMessage() }
        }
        root.addView(send, LinearLayout.LayoutParams.MATCH_PARENT, dp(54).apply { })

        root.addView(TextView(this).apply {
            text = "VOZ FLUX ATH ISOLADA • NÃO USA A VOZ DO GOOGLE"
            textSize = 10f
            gravity = Gravity.CENTER
            setTextColor(Color.rgb(155, 162, 173))
            setPadding(0, dp(10), 0, 0)
        })
        return root
    }

    private fun sendMessage() {
        val message = input.text.toString().trim()
        if (message.isEmpty() || !send.isEnabled) return
        input.setText("")
        conversation.append("\n\nVocê\n$message")
        setBusy(true, "CONECTANDO AO FLUX CORE...")

        Thread {
            runCatching { requestChat(message) }
                .onSuccess { response ->
                    runOnUiThread {
                        conversation.append("\n\nFLUX\n$response")
                        setBusy(false, "ONLINE")
                    }
                }
                .onFailure { failure ->
                    runOnUiThread {
                        conversation.append("\n\nFalha de conexão\n${failure.message ?: "Não foi possível alcançar o Core."}")
                        setBusy(false, "ERRO DE CONEXÃO")
                    }
                }
        }.apply { name = "flux-safe-chat" }.start()
    }

    private fun requestChat(message: String): String {
        var token = ensureToken()
        return try {
            postChat(token, message)
        } catch (failure: CoreFailure) {
            if (failure.status != 401) throw failure
            preferences.edit().remove(KEY_TOKEN).apply()
            token = ensureToken()
            postChat(token, message)
        }
    }

    private fun ensureToken(): String {
        preferences.getString(KEY_TOKEN, null)?.takeIf(String::isNotBlank)?.let { return it }
        val deviceId = deviceId()
        val timestamp = System.currentTimeMillis()
        val nonce = ByteArray(24).also(SecureRandom()::nextBytes).let {
            Base64.encodeToString(it, Base64.URL_SAFE or Base64.NO_WRAP or Base64.NO_PADDING)
        }
        val payload = "flux-pair-v1\n$deviceId\n$timestamp\n$nonce".toByteArray(Charsets.UTF_8)
        val privateKey = KeyFactory.getInstance("RSA").generatePrivate(
            PKCS8EncodedKeySpec(Base64.decode(BuildConfig.FLUX_PAIRING_PRIVATE_KEY, Base64.DEFAULT)),
        )
        val signature = Signature.getInstance("SHA256withRSA").run {
            initSign(privateKey)
            update(payload)
            Base64.encodeToString(sign(), Base64.NO_WRAP)
        }
        val response = request(
            path = "/v1/pair",
            body = JSONObject().apply {
                put("deviceId", deviceId)
                put("deviceName", "FLUX Mobile de Maurício")
                put("timestamp", timestamp)
                put("nonce", nonce)
                put("signature", signature)
            },
            token = null,
        )
        val token = response.getString("deviceToken")
        preferences.edit().putString(KEY_TOKEN, token).apply()
        return token
    }

    private fun postChat(token: String, message: String): String {
        val response = request(
            path = "/v1/chat",
            body = JSONObject().apply {
                put("requestId", UUID.randomUUID().toString())
                put("conversationId", conversationId())
                put("message", message)
                put("deviceId", deviceId())
                put("modality", "TEXT")
            },
            token = token,
        )
        return response.getString("content")
    }

    private fun request(path: String, body: JSONObject, token: String?): JSONObject {
        val core = BuildConfig.FLUX_CORE_URL.trimEnd('/')
        require(core.startsWith("https://")) { "O endereço seguro do FLUX Core não foi configurado." }
        val connection = (URL(core + path).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 15_000
            readTimeout = 180_000
            doOutput = true
            setRequestProperty("Content-Type", "application/json")
            setRequestProperty("Accept", "application/json")
            setRequestProperty("X-Flux-User-Id", "mauricio")
            setRequestProperty("X-Flux-Device-Id", deviceId())
            token?.let { setRequestProperty("Authorization", "Bearer $it") }
        }
        connection.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
        val status = connection.responseCode
        val raw = (if (status in 200..299) connection.inputStream else connection.errorStream)
            ?.bufferedReader()?.use { it.readText() }.orEmpty()
        connection.disconnect()
        if (status !in 200..299) {
            val message = runCatching { JSONObject(raw).optString("message") }.getOrNull()
                ?.takeIf(String::isNotBlank) ?: "FLUX Core respondeu com erro $status."
            throw CoreFailure(status, message)
        }
        return JSONObject(raw)
    }

    private fun deviceId(): String {
        preferences.getString(KEY_DEVICE, null)?.takeIf(String::isNotBlank)?.let { return it }
        return "mobile-${UUID.randomUUID()}".also {
            preferences.edit().putString(KEY_DEVICE, it).apply()
        }
    }

    private fun conversationId(): String {
        preferences.getString(KEY_CONVERSATION, null)?.takeIf(String::isNotBlank)?.let { return it }
        return UUID.randomUUID().toString().also {
            preferences.edit().putString(KEY_CONVERSATION, it).apply()
        }
    }

    private fun setBusy(busy: Boolean, label: String) {
        send.isEnabled = !busy
        status.text = label
        status.setTextColor(if (label == "ONLINE") Color.rgb(82, 210, 127) else Color.rgb(255, 188, 82))
    }

    private fun rounded(color: Int, radius: Int, stroke: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radius).toFloat()
        setStroke(dp(1), stroke)
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private class CoreFailure(val status: Int, message: String) : Exception(message)

    private companion object {
        const val KEY_TOKEN = "device_token"
        const val KEY_DEVICE = "device_id"
        const val KEY_CONVERSATION = "conversation_id"
    }
}
