package ai.flux.mobile

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import ai.flux.mobile.data.FluxApiClient
import ai.flux.mobile.data.FluxApiException
import ai.flux.mobile.data.FluxConnectionSettings
import ai.flux.mobile.data.FluxLocalWorkspace
import ai.flux.mobile.data.FluxNetworkMonitor
import ai.flux.mobile.data.LocalConversationCache
import ai.flux.mobile.model.FluxUiState
import ai.flux.mobile.model.LocalProject
import ai.flux.mobile.model.LocalTask
import ai.flux.mobile.model.PendingChat
import ai.flux.mobile.model.Role
import ai.flux.mobile.model.UiMessage
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

class FluxViewModel(
    private val api: FluxApiClient,
    private val cache: LocalConversationCache,
    private val connectionSettings: FluxConnectionSettings,
    private val workspace: FluxLocalWorkspace,
    private val networkMonitor: FluxNetworkMonitor,
) : ViewModel() {
    private val pendingChats = workspace.loadPendingChats().toMutableList()
    private val connectionMutex = Mutex()
    private val sendMutex = Mutex()
    private val _state = MutableStateFlow(FluxUiState(
        messages = cache.loadMessages(),
        coreUrl = connectionSettings.coreUrl(),
        coreAuthConfigured = connectionSettings.authTokenConfigured(),
        tasks = workspace.loadTasks(),
        projects = workspace.loadProjects(),
        memoryEnabled = workspace.memoryEnabled(),
        moderateProactivity = workspace.moderateProactivity(),
        pendingMessageCount = pendingChats.size,
        showAssistantOnboarding = !workspace.assistantPromptDismissed(),
    ))
    val state = _state.asStateFlow()
    private val _voiceSentences = MutableSharedFlow<String>(extraBufferCapacity = 30)
    val voiceSentences = _voiceSentences.asSharedFlow()
    private var networkAvailable = false
    private var consecutiveConnectionFailures = 0
    private var hasConnectedOnce = false

    init {
        viewModelScope.launch {
            networkMonitor.available.collectLatest { available ->
                networkAvailable = available
                _state.update { it.copy(networkAvailable = available) }
                if (available) {
                    if (connectOnce(showFailure = false)) flushPendingChats()
                } else {
                    // Não apague um estado saudável durante a troca rápida entre
                    // Wi-Fi e 4G/5G. As mensagens permanecem na fila e a conexão
                    // é retomada assim que o Android anunciar outra rede.
                    _state.update { it.copy(isConnecting = false) }
                }
            }
        }
        viewModelScope.launch {
            var retryDelay = 2_000L
            while (isActive) {
                if (networkAvailable && state.value.coreUrl.isNotBlank()) {
                    val connected = connectOnce(showFailure = false)
                    if (connected) {
                        flushPendingChats()
                        retryDelay = 25_000L
                    } else {
                        retryDelay = (retryDelay * 2).coerceAtMost(30_000L)
                    }
                } else {
                    retryDelay = 5_000L
                }
                delay(retryDelay)
            }
        }
    }

    fun reconnect(showFailure: Boolean = true) {
        if (state.value.coreUrl.isBlank()) {
            _state.update {
                it.copy(
                    coreOnline = false,
                    aiReady = false,
                    activationRequired = false,
                    isConnecting = false,
                    voiceConfigured = false,
                    voiceProvider = "unavailable",
                    voiceOfficial = false,
                    error = if (showFailure) "Configure o endereço HTTPS do Flux Core." else null,
                )
            }
            return
        }
        viewModelScope.launch {
            if (connectOnce(showFailure)) flushPendingChats()
        }
    }

    private suspend fun connectOnce(showFailure: Boolean): Boolean = connectionMutex.withLock {
        if (!networkAvailable || state.value.coreUrl.isBlank()) return@withLock false
        _state.update { it.copy(isConnecting = true) }
        runCatching {
            val diagnostics = diagnoseWithAutomaticPairing()
            runCatching { api.registerMobile() }
            diagnostics
        }.fold(
            onSuccess = { diagnostics ->
                consecutiveConnectionFailures = 0
                hasConnectedOnce = true
                _state.update {
                    it.copy(
                        coreOnline = diagnostics.coreOk,
                        aiReady = diagnostics.aiReady,
                        activationRequired = diagnostics.activationRequired,
                        isConnecting = false,
                        voiceConfigured = diagnostics.voiceConfigured,
                        voiceProvider = diagnostics.voiceProvider,
                        voiceOfficial = diagnostics.voiceOfficial,
                        error = null,
                    )
                }
                diagnostics.coreOk
            },
            onFailure = { failure ->
                consecutiveConnectionFailures += 1
                _state.update { current ->
                    current.copy(
                        // Um único timeout não representa desconexão. Mantemos o
                        // último estado bom e só declaramos offline após três falhas.
                        coreOnline = current.coreOnline && consecutiveConnectionFailures < 3,
                        isConnecting = false,
                        error = if (showFailure) failure.message ?: "Não foi possível alcançar o FLUX Core. Vou continuar tentando." else current.error,
                    )
                }
                false
            },
        )
    }

    private suspend fun diagnoseWithAutomaticPairing() = try {
        if (!connectionSettings.authTokenConfigured()) pairDevice()
        api.diagnostics()
    } catch (failure: FluxApiException) {
        if (failure.statusCode != 401 || connectionSettings.pairingPrivateKey().isBlank()) throw failure
        connectionSettings.clearAuthToken()
        pairDevice()
        api.diagnostics()
    }

    private suspend fun pairDevice() {
        val privateKey = connectionSettings.pairingPrivateKey()
        if (privateKey.isBlank()) {
            throw FluxApiException(401, false, "O pareamento automático não está disponível nesta instalação.")
        }
        val paired = api.pair(privateKey)
        connectionSettings.updateAuthToken(paired.deviceToken)
        _state.update { it.copy(coreAuthConfigured = true) }
    }

    fun updateCoreUrl(value: String) {
        runCatching { connectionSettings.updateCoreUrl(value) }
            .onSuccess {
                _state.update { it.copy(coreUrl = connectionSettings.coreUrl(), error = null) }
                reconnect(showFailure = true)
            }
            .onFailure { reportError(it.message ?: "Endereço inválido.") }
    }

    fun updateCoreAuthToken(value: String) {
        runCatching { connectionSettings.updateAuthToken(value) }
            .onSuccess { _state.update { it.copy(coreAuthConfigured = connectionSettings.authTokenConfigured(), error = null) } }
            .onFailure { reportError("Não foi possível proteger o token neste aparelho.") }
    }

    fun setListening(value: Boolean) = _state.update { it.copy(isListening = value) }
    fun setGlasses(name: String?) = _state.update { it.copy(glassesName = name) }
    fun reportError(message: String?) = _state.update { it.copy(error = message) }
    fun clearError() = _state.update { it.copy(error = null) }

    fun setAssistantRoleState(available: Boolean, held: Boolean) {
        if (held) workspace.setAssistantPromptDismissed(true)
        _state.update {
            it.copy(
                assistantCheckComplete = true,
                assistantAvailable = available,
                assistantRoleHeld = held,
                showAssistantOnboarding = available && !held && !workspace.assistantPromptDismissed(),
            )
        }
    }

    fun dismissAssistantPrompt() {
        workspace.setAssistantPromptDismissed(true)
        _state.update { it.copy(showAssistantOnboarding = false) }
    }

    fun addTask(title: String) {
        val clean = title.trim()
        if (clean.isEmpty()) return
        val tasks = state.value.tasks + LocalTask(title = clean)
        workspace.saveTasks(tasks)
        _state.update { it.copy(tasks = tasks) }
    }

    fun toggleTask(id: String) {
        val tasks = state.value.tasks.map { task -> if (task.id == id) task.copy(completed = !task.completed) else task }
        workspace.saveTasks(tasks)
        _state.update { it.copy(tasks = tasks) }
    }

    fun deleteTask(id: String) {
        val tasks = state.value.tasks.filterNot { it.id == id }
        workspace.saveTasks(tasks)
        _state.update { it.copy(tasks = tasks) }
    }

    fun addProject(name: String, objective: String) {
        val cleanName = name.trim()
        if (cleanName.isEmpty()) return
        val projects = state.value.projects + LocalProject(
            name = cleanName,
            objective = objective.trim().ifBlank { "Projeto criado no Flux Mobile" },
        )
        workspace.saveProjects(projects)
        _state.update { it.copy(projects = projects) }
    }

    fun setMemoryEnabled(value: Boolean) {
        workspace.setMemoryEnabled(value)
        _state.update { it.copy(memoryEnabled = value) }
    }

    fun setModerateProactivity(value: Boolean) {
        workspace.setModerateProactivity(value)
        _state.update { it.copy(moderateProactivity = value) }
    }

    fun clearConversation() {
        pendingChats.clear()
        workspace.savePendingChats(emptyList())
        cache.saveMessages(emptyList())
        _state.update { it.copy(messages = emptyList(), pendingMessageCount = 0, error = null) }
    }

    fun send(text: String, voice: Boolean = false) {
        val clean = text.trim()
        if (clean.isEmpty()) return
        // Toda conversa passa pela inteligência real. A antiga resposta local
        // baseada em frases prontas foi removida porque soava artificial.
        val user = UiMessage(role = Role.USER, content = clean, mode = "PENDING")
        val withUser = state.value.messages + user
        cache.saveMessages(withUser)
        _state.update { it.copy(messages = withUser, error = null) }

        val pending = PendingChat(user.id, clean, voice)
        pendingChats.add(pending)
        workspace.savePendingChats(pendingChats)
        _state.update { it.copy(pendingMessageCount = pendingChats.size, isResponding = true) }
        viewModelScope.launch { deliverPending(pending) }
    }

    private suspend fun flushPendingChats() {
        for (pending in pendingChats.toList()) {
            if (!networkAvailable) return
            deliverPending(pending)
        }
    }

    private suspend fun deliverPending(pending: PendingChat) = sendMutex.withLock {
        if (pendingChats.none { it.messageId == pending.messageId }) return@withLock
        if (state.value.coreUrl.isBlank()) {
            markDeliveryWaiting("Configure o servidor HTTPS do Flux para enviar a mensagem.")
            return@withLock
        }
        if (!networkAvailable) {
            markDeliveryWaiting("A mensagem está salva. O FLUX enviará assim que a internet voltar.", keepCoreOnline = true)
            return@withLock
        }

        _state.update { it.copy(isResponding = true, error = null) }
        if (!state.value.coreOnline) connectOnce(showFailure = false)
        if (state.value.coreOnline && state.value.activationRequired && !state.value.aiReady) {
            markDeliveryWaiting(
                message = "O FLUX Core está online. Falta ativar a IA para eu responder.",
                keepCoreOnline = true,
            )
            return@withLock
        }
        var lastError: Throwable? = null
        repeat(3) { attempt ->
            if (!networkAvailable) return@repeat
            if (!state.value.coreOnline) connectOnce(showFailure = false)
            if (!state.value.coreOnline) {
                delay(1_000L shl attempt)
                return@repeat
            }

            runCatching {
                api.chat(
                    requestId = pending.messageId,
                    conversationId = cache.conversationId(),
                    message = pending.content,
                    voice = pending.voice,
                )
            }.onSuccess { result ->
                pendingChats.removeAll { it.messageId == pending.messageId }
                workspace.savePendingChats(pendingChats)
                val completed = state.value.messages.map { message ->
                    if (message.id == pending.messageId) message.copy(mode = null) else message
                } + UiMessage(role = Role.FLUX, content = result.content, mode = result.mode)
                cache.saveMessages(completed)
                _state.update {
                    it.copy(
                        messages = completed,
                        isResponding = false,
                        coreOnline = true,
                        aiReady = true,
                        pendingMessageCount = pendingChats.size,
                        error = null,
                    )
                }
                if (pending.voice && state.value.voiceOfficial) emitVoiceChunks(result.content)
                return@withLock
            }.onFailure { failure ->
                lastError = failure
                if (failure is FluxApiException) {
                    _state.update { it.copy(coreOnline = true) }
                    if (failure.statusCode == 503) {
                        _state.update { it.copy(aiReady = false, activationRequired = true) }
                    }
                    if (!failure.retryable) {
                        markDeliveryWaiting(failure.message ?: "A IA não aceitou esta solicitação.", keepCoreOnline = true)
                        return@withLock
                    }
                } else {
                    consecutiveConnectionFailures += 1
                    _state.update {
                        it.copy(coreOnline = it.coreOnline && consecutiveConnectionFailures < 3)
                    }
                }
            }

            delay(1_000L shl attempt)
        }
        markDeliveryWaiting(
            message = if (lastError == null) "Sem internet agora. A mensagem está salva e será enviada automaticamente."
            else lastError?.message ?: "A mensagem ficou salva. O FLUX tentará novamente.",
            keepCoreOnline = lastError is FluxApiException || (hasConnectedOnce && consecutiveConnectionFailures < 3),
        )
    }

    private fun markDeliveryWaiting(message: String, keepCoreOnline: Boolean = false) {
        val restored = state.value.messages.map { item ->
            if (pendingChats.any { it.messageId == item.id }) item.copy(mode = "PENDING") else item
        }
        cache.saveMessages(restored)
        _state.update {
            it.copy(
                messages = restored,
                isResponding = false,
                coreOnline = if (keepCoreOnline) it.coreOnline else false,
                pendingMessageCount = pendingChats.size,
                error = message,
            )
        }
    }

    private fun emitVoiceChunks(text: String) {
        val sentences = text.split(Regex("(?<=[.!?])\\s+"))
        var chunk = ""
        for (sentence in sentences) {
            if (chunk.isNotBlank() && chunk.length + sentence.length > 320) {
                _voiceSentences.tryEmit(chunk.trim())
                chunk = ""
            }
            chunk += if (chunk.isBlank()) sentence else " $sentence"
        }
        if (chunk.isNotBlank()) _voiceSentences.tryEmit(chunk.trim())
    }
}
