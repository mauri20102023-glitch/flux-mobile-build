package ai.flux.mobile.audio

import android.content.Context
import android.content.Intent
import android.media.MediaPlayer
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import ai.flux.mobile.data.FluxApiClient
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancelChildren
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import java.io.File
import java.io.IOException
import java.security.MessageDigest
import java.util.ArrayDeque
import java.util.Locale
import java.util.UUID

class FluxVoiceController(
    private val context: Context,
    private val client: OkHttpClient,
    private val api: FluxApiClient,
    private val onListeningChanged: (Boolean) -> Unit,
    private val onTranscript: (String) -> Unit,
    private val onError: (String) -> Unit,
) : RecognitionListener {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private val recognizer = SpeechRecognizer.createSpeechRecognizer(context).also { it.setRecognitionListener(this) }
    private val queue = ArrayDeque<String>()
    private var player: MediaPlayer? = null
    private var playbackJob: Job? = null
    private lateinit var localTts: TextToSpeech
    @Volatile private var localTtsReady = false
    @Volatile private var localTtsSpeaking = false
    private val voiceCache = File(context.cacheDir, "flux_voice_01").apply { mkdirs() }

    init {
        localTts = TextToSpeech(context.applicationContext) { status ->
            localTtsReady = status == TextToSpeech.SUCCESS
            if (localTtsReady) localTts.language = Locale("pt", "BR")
        }
        localTts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) = Unit
            override fun onDone(utteranceId: String?) = finishLocalSpeech()
            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) = finishLocalSpeech()
        })
    }

    fun listen() {
        stopSpeaking() // barge-in: ouvir tem prioridade imediata sobre a reprodução.
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "pt-BR")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 1_400L)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 900L)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_MINIMUM_LENGTH_MILLIS, 800L)
        }
        recognizer.startListening(intent)
        onListeningChanged(true)
    }

    fun cancelListening() {
        recognizer.cancel()
        onListeningChanged(false)
    }

    fun speakSentence(text: String) {
        if (text.isBlank()) return
        queue.addLast(text)
        if (playbackJob?.isActive != true && player == null && !localTtsSpeaking) playNext()
    }

    fun stopSpeaking() {
        queue.clear()
        playbackJob?.cancel()
        playbackJob = null
        player?.let { active ->
            runCatching { active.stop() }
            runCatching { active.release() }
        }
        player = null
        localTtsSpeaking = false
        runCatching { localTts.stop() }
        scope.coroutineContext.cancelChildren()
    }

    fun destroy() {
        stopSpeaking()
        recognizer.destroy()
        runCatching { localTts.shutdown() }
    }

    private fun playNext() {
        val sentence = queue.pollFirst() ?: return
        playbackJob = scope.launch {
            runCatching {
                val file = withContext(Dispatchers.IO) {
                    val target = cachedVoiceFile(sentence)
                    if (target.exists() && target.length() > 0L) return@withContext target
                    val partial = File(target.parentFile, "${target.name}.part")
                    partial.delete()
                    var lastFailure: Throwable? = null
                    repeat(3) { attempt ->
                        try {
                            val response = client.newCall(api.voiceRequest(sentence)).execute()
                            response.use {
                                if (!it.isSuccessful) {
                                    if (it.code == 429 || it.code in 500..599) {
                                        lastFailure = IOException("Flux Voice respondeu ${it.code}")
                                    } else {
                                        throw IOException("Flux Voice respondeu ${it.code}")
                                    }
                                } else {
                                    partial.outputStream().use { output -> it.body?.byteStream()?.copyTo(output) }
                                    require(partial.length() > 0L) { "Flux Voice retornou áudio vazio" }
                                    if (!partial.renameTo(target)) {
                                        partial.copyTo(target, overwrite = true)
                                        partial.delete()
                                    }
                                    trimVoiceCache()
                                    return@withContext target
                                }
                            }
                        } catch (failure: IOException) {
                            partial.delete()
                            lastFailure = failure
                        }
                        if (attempt < 2) Thread.sleep(400L * (1L shl attempt))
                    }
                    throw lastFailure ?: IOException("FLUX Voice 01 indisponível")
                }
                player = MediaPlayer().apply {
                    setDataSource(file.absolutePath)
                    setOnPreparedListener { prepared -> prepared.start() }
                    setOnCompletionListener {
                        it.release()
                        player = null
                        playNext()
                    }
                    setOnErrorListener { mediaPlayer, _, _ ->
                        mediaPlayer.release()
                        player = null
                        playNext()
                        true
                    }
                    // A preparação síncrona travava a interface em aparelhos mais
                    // lentos. O áudio continua sendo exclusivamente FLUX Voice 01.
                    prepareAsync()
                }
            }.onFailure {
                player = null
                playbackJob = null
                if (!speakLocally(sentence)) {
                    onError("A resposta em texto continua disponível; a voz está temporariamente indisponível.")
                    playNext()
                }
            }
        }
    }

    private fun speakLocally(text: String): Boolean {
        if (!localTtsReady) return false
        localTtsSpeaking = true
        val result = localTts.speak(
            text,
            TextToSpeech.QUEUE_FLUSH,
            null,
            "flux-local-${UUID.randomUUID()}",
        )
        if (result == TextToSpeech.ERROR) localTtsSpeaking = false
        return result != TextToSpeech.ERROR
    }

    private fun finishLocalSpeech() {
        scope.launch {
            localTtsSpeaking = false
            playbackJob = null
            playNext()
        }
    }

    private fun cachedVoiceFile(text: String): File {
        val digest = MessageDigest.getInstance("SHA-256").digest(text.toByteArray())
        val key = digest.joinToString("") { byte -> "%02x".format(byte) }
        return File(voiceCache, "$key.mp3")
    }

    private fun trimVoiceCache() {
        val files = voiceCache.listFiles()?.sortedByDescending(File::lastModified).orEmpty()
        var total = 0L
        files.forEach { file ->
            total += file.length()
            if (total > 32L * 1024L * 1024L) file.delete()
        }
    }

    override fun onReadyForSpeech(params: Bundle?) = Unit
    override fun onBeginningOfSpeech() = Unit
    override fun onRmsChanged(rmsdB: Float) = Unit
    override fun onBufferReceived(buffer: ByteArray?) = Unit
    override fun onEndOfSpeech() { onListeningChanged(false) }
    override fun onError(error: Int) {
        onListeningChanged(false)
        val message = when (error) {
            SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT ->
                "Não ouvi uma frase completa. Toque no microfone e fale novamente."
            SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS ->
                "Autorize o microfone para conversar por voz."
            SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT ->
                "O reconhecimento de voz perdeu a internet, mas o FLUX continua aberto."
            else -> "O reconhecimento de voz parou. Toque no microfone para tentar novamente."
        }
        onError(message)
    }
    override fun onResults(results: Bundle?) {
        onListeningChanged(false)
        results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.let(onTranscript)
    }
    override fun onPartialResults(partialResults: Bundle?) = Unit
    override fun onEvent(eventType: Int, params: Bundle?) = Unit
}
