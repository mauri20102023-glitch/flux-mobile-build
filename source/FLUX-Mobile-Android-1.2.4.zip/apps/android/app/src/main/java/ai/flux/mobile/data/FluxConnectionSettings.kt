package ai.flux.mobile.data

import android.content.Context
import ai.flux.mobile.BuildConfig
import java.net.URI

class FluxConnectionSettings(context: Context) {
    private val preferences = context.getSharedPreferences("flux_connection", Context.MODE_PRIVATE)
    private val secureTokenStore = FluxSecureTokenStore(context)

    fun coreUrl(): String = preferences.getString("core_url", "")
        .orEmpty()
        .trimEnd('/')
        .ifBlank { BuildConfig.FLUX_CORE_URL.trimEnd('/') }

    fun updateCoreUrl(value: String) {
        val normalized = value.trim().trimEnd('/')
        require(normalized.startsWith("https://") || isPrivateLocalHttp(normalized)) {
            "Use HTTPS ou um endereço local privado do Flux Core"
        }
        preferences.edit().putString("core_url", normalized).apply()
    }

    private fun isPrivateLocalHttp(value: String): Boolean = runCatching {
        val uri = URI(value)
        if (uri.scheme != "http") return@runCatching false
        val host = uri.host?.lowercase() ?: return@runCatching false
        host == "localhost" || host == "127.0.0.1" || host.startsWith("10.") ||
            host.startsWith("192.168.") || Regex("^172\\.(1[6-9]|2\\d|3[01])\\.").containsMatchIn(host)
    }.getOrDefault(false)

    fun authToken(): String = secureTokenStore.read().ifBlank { BuildConfig.FLUX_DEV_TOKEN }

    fun authTokenConfigured(): Boolean = authToken().isNotBlank()

    fun updateAuthToken(value: String) {
        secureTokenStore.write(value)
    }
}
