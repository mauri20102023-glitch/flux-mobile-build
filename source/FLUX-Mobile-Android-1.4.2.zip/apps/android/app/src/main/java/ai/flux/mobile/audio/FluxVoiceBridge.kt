package ai.flux.mobile.audio

/**
 * Contrato sem dependências externas usado pela tela principal.
 *
 * A implementação ElevenLabs é descoberta apenas quando o usuário toca no
 * microfone. Isso impede o verificador do Android de carregar WebRTC durante a
 * inicialização do aplicativo.
 */
interface FluxVoiceBridge {
    fun startSession()
    fun endSession()
    fun destroy()
}
